=========================
NiPyApi Package Reference
=========================

.. toctree::
   :maxdepth: 4

   nipyapi-docs/nipyapi
