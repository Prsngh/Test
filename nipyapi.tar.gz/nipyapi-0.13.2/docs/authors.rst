=======
Credits
=======

Development Lead
----------------

* Daniel Chaffelson <chaffelson@gmail.com>

Contributors
------------

Kevin Doran <kdoran@apache.org>

Shout Outs
----------

This package was created with Cookiecutter_ and the `audreyr/cookiecutter-pypackage`_ project template

.. _Cookiecutter: https://github.com/audreyr/cookiecutter
.. _`audreyr/cookiecutter-pypackage`: https://github.com/audreyr/cookiecutter-pypackage

Inspired by the equivalent Java client maintained over at
`hermannpencole/nifi-config <https://github.com/hermannpencole/nifi-config>`_

The swagger 2.0 compliant client auto-generated using the
`Swagger Codegen <https://github.com/swagger-api/swagger-codegen>`_ project,
and then cleaned / bugfixed by the authors

Props to the NiFi-dev and NiFi-user mailing list members over at Apache for all the assistance and kindnesses.
