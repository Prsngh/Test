NiPyApi: A Python Client SDK for Apache NiFi
============================================

Contents:

.. toctree::
   :maxdepth: 4

   readme
   installation
   apiReference
   todo
   contributing
   devnotes
   authors
   history

Indices and tables
==================

* :ref:`genindex`
* :ref:`search`
