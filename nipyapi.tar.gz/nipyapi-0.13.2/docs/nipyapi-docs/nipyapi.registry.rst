NiFi-Registry Swagger Client
============================

Subpackages
-----------

.. toctree::

   nipyapi.registry.apis
   nipyapi.registry.models

Submodules
----------

nipyapi.registry.api\_client module
-----------------------------------

.. automodule:: nipyapi.registry.api_client
    :members:
    :undoc-members:
    :show-inheritance:

nipyapi.registry.configuration module
-------------------------------------

.. automodule:: nipyapi.registry.configuration
    :members:
    :undoc-members:
    :show-inheritance:

nipyapi.registry.rest module
----------------------------

.. automodule:: nipyapi.registry.rest
    :members:
    :undoc-members:
    :show-inheritance:
