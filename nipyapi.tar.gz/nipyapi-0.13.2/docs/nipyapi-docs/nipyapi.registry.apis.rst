nipyapi.registry.apis package
=============================

Submodules
----------

nipyapi.registry.apis.access\_api module
----------------------------------------

.. automodule:: nipyapi.registry.apis.access_api
    :members:
    :undoc-members:
    :show-inheritance:

nipyapi.registry.apis.bucket\_flows\_api module
-----------------------------------------------

.. automodule:: nipyapi.registry.apis.bucket_flows_api
    :members:
    :undoc-members:
    :show-inheritance:

nipyapi.registry.apis.buckets\_api module
-----------------------------------------

.. automodule:: nipyapi.registry.apis.buckets_api
    :members:
    :undoc-members:
    :show-inheritance:

nipyapi.registry.apis.flows\_api module
---------------------------------------

.. automodule:: nipyapi.registry.apis.flows_api
    :members:
    :undoc-members:
    :show-inheritance:

nipyapi.registry.apis.items\_api module
---------------------------------------

.. automodule:: nipyapi.registry.apis.items_api
    :members:
    :undoc-members:
    :show-inheritance:

nipyapi.registry.apis.policies\_api module
------------------------------------------

.. automodule:: nipyapi.registry.apis.policies_api
    :members:
    :undoc-members:
    :show-inheritance:

nipyapi.registry.apis.tenants\_api module
-----------------------------------------

.. automodule:: nipyapi.registry.apis.tenants_api
    :members:
    :undoc-members:
    :show-inheritance:
